let cart = localStorage.getItem('cart') ? JSON.parse(localStorage.getItem('cart')):[];

// Hiển thị giỏ hàng
function showcart  (){
    document.querySelector('tbody').innerHTML="" 
    cart.forEach((item, index) => {
        document.querySelector('tbody').innerHTML += `
          <tr>
            <td>${index + 1}</td>
            <td>${item.name}</td>
            <td><img src="image/${item.image}" alt="${item.name}" width="50"></td>
            <td>${item.sale}</td>
           <td>
          <input type="number" class="qty"  data-id="${item.id}" min="1" value="${item.qty}"</input>
        </td>
            <td>${item.qty * item.sale}</td>
            <td>
              <button class="delPro" data-id="${item.id}">Xóa</button>
            </td>
          </tr>
        `;
      });
}
showcart();
// Tính tổng tiền
let sum = 0;
cart.forEach(item => {
  sum += item.sale * item.qty;
});

// Định dạng số tiền (thêm dấu phẩy và đơn vị VNĐ)
const formattedSum = sum.toLocaleString('vi-VN', { style: 'currency', currency: 'VND' });

// Gán tổng tiền đã định dạng vào phần tử HTML
document.getElementById('sumMoney').innerHTML = formattedSum;

// Xóa sản phẩm trong giỏ hàng
document.addEventListener('click', (e) => {
  if (e.target.classList.contains('delPro')) {
    const id = e.target.getAttribute('data-id');
    console.log(id); // Log ra ID của sản phẩm cần xóa
    const index = cart.findIndex(item => item.id == id);
    if (index !== -1) {
      cart.splice(index, 1); // Xóa sản phẩm khỏi mảng
      localStorage.setItem('cart', JSON.stringify(cart)); // Cập nhật lại localStorage
     showcart(); // Reload lại trang
    }
  }
});
// thay đổi  số lượng sản phẩm
document.addEventListener('change', (e) => {
    if (e.target.classList.contains('qty')) {
      // Lấy ID của sản phẩm từ thuộc tính data-id
      const id=e.target.getAttribute('data-id');
      const value=e.target.value
      console.log(id);
  
      // Tìm vị trí (index) của sản phẩm trong giỏ hàng dựa vào ID
      const index = cart.findIndex(item => item.id == id);
  
      // Tăng số lượng sản phẩm
      cart[index].qty=value;
  
      // Lưu giỏ hàng cập nhật vào localStorage
      localStorage.setItem('cart', JSON.stringify(cart));
  
      // Tải lại trang để cập nhật giao diện
      showcart(); // Reload lại trang
    }
  });
//   // Giảm số lượng sản phẩm
// document.addEventListener('click', (e) => {
//     if (e.target.classList.contains('sub')) {
//       // Lấy ID của sản phẩm từ thuộc tính data-id
//       const id = e.target.getAttribute('data-id');
//       console.log(id);
  
//       // Tìm vị trí (index) của sản phẩm trong giỏ hàng dựa vào ID
//       const index = cart.findIndex(item => item.id == id);
  
//       // Giảm số lượng sản phẩm, nhưng không giảm dưới 1
//       if (cart[index].qty > 1) {
//         cart[index].qty -= 1;
  
//         // Lưu giỏ hàng cập nhật vào localStorage
//         localStorage.setItem('cart', JSON.stringify(cart));
  
//         // Tải lại trang để cập nhật giao diện
//         window.location.reload();
//       } else {
//         alert('Số lượng sản phẩm không thể nhỏ hơn 1.');
//       }
//     }
//   });
  