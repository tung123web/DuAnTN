export class productService{
    static async fetchData (url) {
    try {
    const reponse= await axios.get(url);
    return reponse.data;
    } catch (error) {
    console.log(error);
    throw error;
    }

    
}
static async addData(data) {
    try {
        await axios.post('http://localhost:3000/products', data);
        console.log("Đã thêm sản phẩm thành công");
    } catch (error) {
        console.log(error);
        throw error;
    }
}
static async getLasId   () {
    try {
        const reponse= await axios.get('http://localhost:3000/products');
        return reponse.data[reponse.data.length-1].id;
        } catch (error) {
        console.log(error);
        throw error;
        }
}  

// xoa san pham
static async deleteData(id){
    try {
    await axios.delete(`http://localhost:3000/products/${id}`)
    console.log('xoa thanh cong')
    } catch (error) {
    console.log(error);
    throw error;
}}
//sửa sản phẩm
static async getDataById(id) {
    try {
        const response = await axios.get(`http://localhost:3000/products/${id}`);
        return response.data;
    } catch (error) {
        console.log(error);
        throw error;
    }
}
// cap nhat 
static async updateData(id,data) {
    try {
    await axios.put(`http://localhost:3000/products/${id}`, data);
    console.log('cap nhat thanh cong')
    } 
    catch (error){
    console.log(error);
    throw error;
}
}
async getProductById(id) {
    try {
        const products = await this.getProducts();
        // Tìm sản phẩm có ID khớp (so sánh dưới dạng chuỗi)
        return products.find(product => product.id === id) || null;
    } catch (error) {
        console.error("Lỗi khi lấy sản phẩm:", error);
        throw error;
    }
}

}

