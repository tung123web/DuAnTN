import { productService } from "../model/model.js";
const tbody = document.querySelector('tbody');

function showPro() {
  tbody.innerHTML =""
  productService.fetchData('http://localhost:3000/products').then(data=>{
 data.forEach(function (item, index) {
                  tbody.innerHTML +=`
      <tr>
        <td>${index + 1}</td>
        <td>${item.name}</td>
        <td><img src="../image/${item.image}" width="120px"></td>
        <td>${item.price}</td>
        <td>${item.sale}</td>
        <td>${item.category}</td>
        <td>${item.hotdeal}</td>
        <td>${item.star}</td>
        <td>${item.description}</td>
        <td>
              <button class="openEditPage" data-id="${item.id}">Sửa</button>
              <button class="deletePro" data-id="${item.id}">Xóa</button>
            </td>
      </tr>
    `
  })
})
  }
 


showPro() 
    const addModal = document.querySelector('#addModal');
    const closeAdd = document.querySelector('.close');
    document.querySelector('#openAddPage').onclick = function () {
        addModal.style.display = "block";
    }
    closeAdd.onclick = function () {
        addModal.style.display = "none";
    }

    var hotdeal = 0;
    document.querySelector('#hotdeal').onchange=function () {
        if (this.checked) {
            hotdeal = 1;
        } else {
            hotdeal = 0;
        }
    };
    
    document.querySelector('#addPro').onclick = function () {
        const name = document.querySelector('#name').value;
        const image = document.querySelector('#image').value.split('\\').pop();
        const price = document.querySelector('#price').value;
        const sale = document.querySelector('#sale').value;
        const category = document.querySelector('#category').value;
        const description = document.querySelector('#description').value;
        var hotdeal = document.querySelector('#hotdeal').checked;
        console.log(name+image+price+sale+category+description);
    
  productService.getLasId().then(id=>{
      const pro = {
          'id': (Number(id)+1).toString(),
         // Lấy ID mới dựa trên phần tử cuối trong mảng `data`
            'name': name,
            'image': image,
            'price': price,
            'sale': sale,
            'category': category,
            'hotdeal': hotdeal,
            'star': 5, // Gán mặc định số sao
            'description': description
        }
        productService.addData(pro);
    })
       // Thêm sản phẩm mới vào mảng `data`
        addModal.style.display = "none";
        showPro() 
    }

//xóa sản phâm
document.querySelector('tbody').addEventListener("click", function(e) {
    if(e.target.classList.contains('deletePro')){
    const id = e.target.dataset.id;
    console.log(id)
    productService.deleteData(id);
    showPro()
    }
});
//sửa sản phâm
  // Sửa sản phẩm - Lấy modal chỉnh sửa
  const editModal = document.querySelector('#editModal');
document.querySelector('tbody').addEventListener("click", function(e){
    if(e.target.classList.contains('openEditPage')){
    const id = e.target.dataset.id;
productService.getDataById(id).then(pro=>{
    editModal.style.display = 'block';

    // Thêm nội dung HTML vào modal
    editModal.innerHTML += `
        <div class="modal-content">
            <span class="close" onclick="closeEditModal()">&times;</span>
            <div class="form">
                <label for="name">Tên sản phẩm</label><br />
                <input type="text" id="editName" value="${pro.name}" /><br />
                
             <label for="">Hình ảnh</label>
                <br />
                <img id="showImage" src="../image/${pro.image}" width="200px">
                <br>
                <input type="file" id="editImage" />
                <br />
              

               <label for="price">Giá</label><br />
                <input type="text" id="editPrice" value="${pro.price}" /><br />
                
                <label for="sale">Khuyến mãi</label><br />
                <input type="text" id="editSale" value="${pro.sale}" /><br />
                <label for="">Danh mục</label>
                <br />
                <select id="editCategory">
                <option ${pro.category=="Tivi"?"selected":""} value="Tivi">Tivi</option>
                <option ${pro.category=="tủ lạnh"?"selected":""} value="tủ lạnh">Tủ lạnh</option>
                </select>
                <br />
                <label for="">Hotdeal</label>
                <br />
                <input ${pro.hotdeal=="1"?"checked":""} type="checkbox" id="editHotdeal" />
                <br />
                <label for="">Mô tả</label>
                <br />
                <input value="${pro.description}" type="text" id="editDescription" />
                <br />
                <button class="editPro" data-id="${id}" id="editPro">Sửa</button>
                </div>
                <div>
              
                
              
    `;
})

    }

});
 //sua sản phâm
editModal.addEventListener("click", function(e) {
    if(e.target.classList.contains('editPro')){
    const id = e.target.dataset.id;
    const editName = document.querySelector('#editName').value;
  var editImage = document.querySelector('#editImage').value.split("\\").pop();
  if (editImage === "") {
      editImage=document.querySelector("#showImage").scr.split("/").pop();
  }
  const editPrice = document.querySelector('#editPrice').value;
  const editSale = document.querySelector('#editSale').value;
  const editCategory = document.querySelector('#editCategory').value;
  var editHotdeal = document.querySelector('#editHotdeal').checked;
  const editDescription = document.querySelector('#editDescription').value;

  console.log(editName + editImage + editPrice + editSale + editCategory + editHotdeal + editDescription);

  const pro = {
      'id': id,
      'name': editName,
      'image': editImage,
      'price': editPrice,
      'sale': editSale,
      'category': editCategory,
      'hotdeal': editHotdeal == true ? 1 : 0,
      'star': 5,
      'description': editDescription
  };

  productService.updateData(id,pro)
  editModal.style.display = 'none';
  showPro();
    }
});

// Hàm mở trang chỉnh sửa
// function openEditPage(id) {
//     // Tìm sản phẩm theo ID trong danh sách `data`
//     const pro = data.find(item => item.id == id);

//     // Kiểm tra nếu không tìm thấy sản phẩm
//     if (!pro) {
//         alert('Không tìm thấy sản phẩm!');
//         return;
//     }

//     // Hiển thị modal
  
// }
function editPro(id) {
  const editName = document.querySelector('#editName').value;
  var editImage = document.querySelector('#editImage').value.split("\\").pop();
  if (editImage === "") {
      editImage = data.find(item => item.id == id).image;
  }
  const editPrice = document.querySelector('#editPrice').value;
  const editSale = document.querySelector('#editSale').value;
  const editCategory = document.querySelector('#editCategory').value;
  var editHotdeal = document.querySelector('#editHotdeal').checked;
  const editDescription = document.querySelector('#editDescription').value;

  console.log(editName + editImage + editPrice + editSale + editCategory + editHotdeal + editDescription);

  const pro = {
      'id': id,
      'name': editName,
      'image': editImage,
      'price': editPrice,
      'sale': editSale,
      'category': editCategory,
      'hotdeal': editHotdeal == true ? 1 : 0,
      'star': 5,
      'description': editDescription
  };

  data = data.map(item => item.id == id ? pro : item);
  editModal.style.display = 'none';
  showPro();
}



  // Thực hiện xử lý với các dữ liệu trên (ví dụ: gửi lên server, cập nhật UI,...)
  // Bạn có thể sử dụng fetch API hoặc axios để gửi request.


// Hàm đóng modal
function closeEditModal() {
    editModal.style.display = 'none';
    editModal.innerHTML = ''; // Xóa nội dung cũ
    showPro()
}

// Hàm lưu chỉnh sửa
function saveEdit(id) {
    // Lấy dữ liệu từ các trường input
    const editedData = {
        name: document.querySelector('#name').value,
        image: document.querySelector('#image').value.split("\\").pop(),
        price: document.querySelector('#price').value,
        sale: document.querySelector('#sale').value,
        category: document.querySelector('#category').value,
        hotdeal: document.querySelector('#hotdeal').checked ? 1 : 0,
        description: document.querySelector('#description').value,
    };

    // Gửi dữ liệu lên server hoặc cập nhật danh sách
    console.log('Dữ liệu đã chỉnh sửa:', { id, ...editedData });

    // Đóng modal sau khi lưu
    closeEditModal();
}
// function deletePro(id) {
//   // Lọc danh sách để loại bỏ sản phẩm có id cần xóa
//   data = data.filter(item => item.id != id);
//   showPro();
 
  
// }
