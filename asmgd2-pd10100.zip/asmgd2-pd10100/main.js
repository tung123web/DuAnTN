 import { productService } from "../model/model.js";
// // Lọc sản phẩm hot deal


// // Chọn các phần tử HTML theo ID
// const cate_hotdeal = document.querySelector("#hotdeal");
// const cate_tivi = document.querySelector("#tivi");
// const cate_tulanh = document.querySelector("#tulanh");
//  productService.fetchData('http://localhost:3000/products?hotdeal=1').then(data=>{
//import productService from "../model/model.js";

    const cate_hotdeal = document.getElementById('hotdeal');
    const cate_tivi = document.getElementById('tivi');
    const cate_tulanh = document.getElementById('tulanh');
    
    productService.fetchData('http://localhost:3000/products?hotdeal=1&_sort=sale&_limit=5').then(data => {
        data.forEach(function(item){
          cate_hotdeal.innerHTML += `
            <div class="sanpham border-blue">
              <span class="label-trago">Trả góp 0%</span>
              <img src="image/${item.image}" alt="" />
              <span class="label-sale">
                <i class="fa-regular fa-bell"></i> FLASH SALE GIÁ SỐC
              </span><br>
              <span>${item.name}</span><br>
              <p class="gia">${item.sale} đ<del> ${item.price} đ</del></p>
             
               <p class="online-gia-re">Online giá rẻ</p>
              <p class="sao">${item.star} <i class="fa-solid fa-star"></i></p>
               <div class="div_btn_buy">
           <a href="cart.html" data-id="${item.id}" class="btn_buy">Mua ngay </a>

          </div>

            </div>
          `;
        });
      });
      productService.fetchData('http://localhost:3000/products?category=Tivi&_limit=5').then(data => {
        data.forEach(function(item){
          cate_tivi.innerHTML += `
            <div class="sanpham border-blue">
              <span class="label-trago">Trả góp 0%</span>
              <img src="image/${item.image}" alt="" />
              <span class="label-sale">
                <i class="fa-regular fa-bell"></i> FLASH SALE GIÁ SỐC
              </span><br>
              <span>${item.name}</span><br>
              <p class="gia">${item.sale} đ<del> ${item.price} đ</del></p>
             
               <p class="online-gia-re">Online giá rẻ</p>
              <p class="sao">${item.star} <i class="fa-solid fa-star"></i></p>
               <div class="div_btn_buy">
  <a href="cart.html" data-id="${item.id}" class="btn_buy">Mua ngay </a>
</div>

            </div>
          `;
        });
      });
      productService.fetchData('http://localhost:3000/products?category=tủ%20lạnh&_limit=5').then(data => {
        data.forEach(function(item){
          cate_tulanh.innerHTML += `
            <div class="sanpham border-blue">
              <span class="label-trago">Trả góp 0%</span>
              <img src="image/${item.image}" alt="" />
              <span class="label-sale">
                <i class="fa-regular fa-bell"></i> FLASH SALE GIÁ SỐC
              </span><br>
              <span>${item.name}</span><br>
              <p class="gia">${item.sale} đ<del> ${item.price} đ</del></p>
             
               <p class="online-gia-re">Online giá rẻ</p>
              <p class="sao">${item.star} <i class="fa-solid fa-star"></i></p>
              <div class="div_btn_buy">
   <a href="cart.html" data-id="${item.id}" class="btn_buy">Mua ngay </a>
</div>

            </div>
          `;
        });
      });         
// // Hàm để định dạng giá
// function formatPrice(price) {
//     return price.toLocaleString() + ' đ';
// }

// // Hàm để tạo HTML cho mỗi sản phẩm
// function createProductHTML(item, borderColor) {
//     return `
//         <div class="sanpham ${borderColor}">
//             <span class="label-tragop">Trả góp 1%</span>
//             <img src="image/${item.image}" alt="${item.name}" />
//             <span class="label-sale">
//                 <i class="fa-regular fa-bell"></i> FLASH SALE GIÁ SỐC
//             </span>
//             <br />
//             <span>${item.name}</span>
//             <br />
//             <p class="gia">${formatPrice(item.price)} <del>${formatPrice(item.sale)}</del></p>
//             <p class="online-gia-re">Online giá rẻ</p>
//             <p class="sao">${item.star} <i class="fa-solid fa-star"></i><br />
//             <a href="chitiet/index.html?id=${item.id}" class="btn-buy">Mua Hàng</a>
//             </p>
//         </div>
//     `;
// }

// // Hiển thị sản phẩm hot deal
// pro_hotdeal.forEach(function(item) {
//     cate_hotdeal.innerHTML += createProductHTML(item, "border-blue");
// });

// // Hiển thị sản phẩm Tivi
// pro_tivi.forEach(function(item) {
//     cate_tivi.innerHTML += createProductHTML(item, "border-green");
// });

// // Hiển thị sản phẩm Tủ lạnh
// pro_tulanh.forEach(function(item) {
//     cate_tulanh.innerHTML += createProductHTML(item, "border-red");
// });

/// Thêm vào giỏ hàng
document.addEventListener('click', async (e) => {
  // Kiểm tra nếu phần tử được click có chứa class 'btn_buy'
  if (e.target.classList.contains('btn_buy')) {
    // Lấy ID sản phẩm từ thuộc tính 'data-id' của phần tử
    const id = e.target.getAttribute('data-id');
    console.log(id);

    // Lấy dữ liệu sản phẩm dựa trên ID
    const product = await productService.getDataById(id);
    console.log(product);

    // Kiểm tra xem giỏ hàng có trong localStorage không, nếu có thì lấy nó
    let cart = localStorage.getItem('cart') ? JSON.parse(localStorage.getItem('cart')):[];

    // Tìm vị trí của sản phẩm trong giỏ hàng dựa trên ID
    const index = cart.findIndex((item) => item.id === product.id);

    if (index === -1) {
      // Nếu sản phẩm chưa có trong giỏ hàng
      product.qty = 1; // Đặt số lượng sản phẩm là 1
      cart.push(product); // Thêm sản phẩm vào giỏ hàng
    } else {
      // Nếu sản phẩm đã tồn tại trong giỏ hàng
      cart[index].qty += 1; // Tăng số lượng sản phẩm
    }

    // Lưu giỏ hàng vào localStorage
    localStorage.setItem('cart', JSON.stringify(cart));

    // In ra giỏ hàng từ localStorage để kiểm tra
    console.log(JSON.parse(localStorage.getItem('cart')));
  }
});

